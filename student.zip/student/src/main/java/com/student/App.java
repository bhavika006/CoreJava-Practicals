package com.student;

import java.io.IOException;
import java.io.Reader;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import com.student.model.Student;

public class App {

	public static void main(String[] args) throws IOException {
		Reader reader = Resources.getResourceAsReader("mybatis-confi.xml");

		SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);

		SqlSession session = sqlSessionFactory.openSession();

		Student student = new Student("Naitik", "Engineer", 80, "8780741688", "naitik006@gmail.com");

		session.insert("com.student.model.Student.insert", student);
		System.out.println("record inserted successfully");

		session.commit();
		session.close();
	}

}
